"""Helpers for building DLT (Lakeflow Declarative Pipelines) datasets.

Follow DLT guidance: dataset-defining functions should only return a DataFrame
and must not perform writes or side effects.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, List

from pyspark.sql import DataFrame, SparkSession

from datalab_etl.common.io import read_dataset


TransformFn = Callable[[DataFrame], DataFrame]


def dlt_stream_transform(spark: SparkSession, *, source: Dict[str, Any], transform: TransformFn) -> DataFrame:
    """Read a streaming source from config and apply the provided transform.

    This function is safe to call inside DLT dataset definitions as it returns a
    DataFrame and does not perform any writes.
    """
    stream_df = read_dataset(spark, source, streaming=True)
    return transform(stream_df)


def dlt_quality_checks_from_config(quality_config: Dict[str, Any]) -> List[Dict[str, str]]:
    """Convert quality config to DLT expectation format.
    
    Converts quality checks from the standard format used in batch pipelines
    to the format expected by DLT @dlt.expect* decorators.
    
    Parameters
    ----------
    quality_config : Dict[str, Any]
        Quality configuration with 'checks' list
        
    Returns
    -------
    List[Dict[str, str]]
        List of DLT expectations with 'name', 'constraint', and 'action' keys
        
    Examples
    --------
    >>> quality_cfg = {
    ...     "checks": [
    ...         {"name": "valid_id", "criticality": "drop", "constraint": "id IS NOT NULL"},
    ...         {"name": "valid_temp", "criticality": "warn", "constraint": "temp > 0"}
    ...     ]
    ... }
    >>> expectations = dlt_quality_checks_from_config(quality_cfg)
    >>> # Returns:
    >>> # [
    >>> #   {"name": "valid_id", "constraint": "id IS NOT NULL", "action": "drop"},
    >>> #   {"name": "valid_temp", "constraint": "temp > 0", "action": "warn"}
    >>> # ]
    """
    checks = quality_config.get("checks", [])
    expectations = []
    
    for check in checks:
        name = check.get("name", "")
        constraint = check.get("constraint", "")
        criticality = check.get("criticality", "warn").lower()
        
        # Map criticality to DLT action
        if criticality in {"error", "drop"}:
            action = "drop"
        elif criticality == "fail":
            action = "fail"
        else:
            action = "warn"
        
        if name and constraint:
            expectations.append({
                "name": name,
                "constraint": constraint,
                "action": action
            })
    
    return expectations


def apply_dlt_expectations(func: Callable, expectations: List[Dict[str, str]]) -> Callable:
    """Apply DLT expectations to a table function.
    
    This is a helper to programmatically apply @dlt.expect* decorators
    based on config-driven expectations.
    
    Parameters
    ----------
    func : Callable
        The DLT table function
    expectations : List[Dict[str, str]]
        List of expectations with 'name', 'constraint', 'action'
        
    Returns
    -------
    Callable
        The function with DLT expectations applied
        
    Examples
    --------
    >>> expectations = [
    ...     {"name": "valid_id", "constraint": "id IS NOT NULL", "action": "drop"}
    ... ]
    >>> 
    >>> @apply_dlt_expectations(my_table_func, expectations)
    >>> def my_table():
    ...     return spark.table("source")
    """
    try:
        import dlt
    except ImportError:
        # DLT not available (local testing) - return function as-is
        return func
    
    # Apply expectations based on action
    for exp in expectations:
        name = exp.get("name", "")
        constraint = exp.get("constraint", "")
        action = exp.get("action", "warn")
        
        if not name or not constraint:
            continue
        
        if action == "drop":
            func = dlt.expect_or_drop(name, constraint)(func)
        elif action == "fail":
            func = dlt.expect_or_fail(name, constraint)(func)
        else:  # warn
            func = dlt.expect(name, constraint)(func)
    
    return func


